/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.java_crud_postgresql;

/**
 *
 * @author Alienware
 */
public class Inicio {

    public static void main(String[] args) {
        
        
        VistaAlumno odjetoVista = new VistaAlumno();
        odjetoVista.setVisible(true);
        
    }
}
